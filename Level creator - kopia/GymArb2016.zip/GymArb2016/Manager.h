#pragma once
#include <SDL\SDL.h>
#include "Player.h"
#include <string>

class Manager
{
public:
	//Initializing variables
	Manager();

	//Calls for close() upon game exit
	~Manager();

	//Runs the game 
	void run();

	std::vector<SDL_Rect> rects;

private:

	//Start the game loop
	void gameLoop();

	//Initializing the systems
	void initSystems();

	void close();

	bool _isRunning;

	SDL_Event evnt;

	//The game window
	SDL_Window *window;

	//The game renderer
	SDL_Renderer *renderer;

	//Width and height of the game window
	int _windowHeight, _windowWidth;

	float frameTime = 0;
	int prevTime = 0;
	int currentTime = 0;
	float deltaTime = 0;

	SDL_Texture * backgroundTexture;
	
	SDL_Texture *loadBackground(std::string path);	
};

