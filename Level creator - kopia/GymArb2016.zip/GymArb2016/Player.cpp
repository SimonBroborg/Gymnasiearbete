#include "Player.h"
#include <SDL/SDL_image.h>
#include <iostream>


Player::Player(SDL_Renderer *renderer, std::string filePath, int x, int y, int framesX, int framesY)
{
	SDL_Surface *surface = IMG_Load(filePath.c_str());
	if (surface == nullptr)
		std::cout << "Error: " << SDL_GetError() << std::endl;
	
	else
	{
		texture = SDL_CreateTextureFromSurface(renderer, surface);
		if (texture == nullptr)
			std::cout << "Error: " << SDL_GetError() << std::endl;
	}

	SDL_FreeSurface(surface);

	SDL_QueryTexture(texture, nullptr, nullptr, &cropRect.w, &cropRect.h);

	//Displays the player on chosen coordinates
	posRect.x = x;
	posRect.y = y;

	//sets the width of the cropRect which will display the different frames of the movement animation
	_textureWidth = cropRect.w;
	
	//sets the width of each frame
	cropRect.w /= framesX;

	//set the height of each frame
	cropRect.h /= framesY;

	//Set the width and height of the frames and rects equal to each other
	_frameWidth = posRect.w = cropRect.w;
	_frameHeight = posRect.h = cropRect.h;

	_leftSpeed = 137; //players velocity to the left
	_rightSpeed = 180; //players velocity to the right
	_jumpSpeed = 1300.0f; //the speed or power that the player jumps with
	gravity = 1000.0f; //gravity which pushes the player downwards

	jumping = false; //The player is not jumping when the game starts
	_isMoving = false; //The player is not moving when the game starts

	
}


Player::~Player()
{
	SDL_DestroyTexture(texture);
}

void Player::render(SDL_Renderer *renderer)
{
	SDL_RenderCopy(renderer, texture, &cropRect, &posRect);
}


void Player::processInput(SDL_Event &evnt, float delta)
{
	_isMoving = false;
	if (evnt.type == SDL_KEYDOWN)

		switch (evnt.key.keysym.scancode) {

		case SDL_SCANCODE_LEFT:
			_velX = -_leftSpeed;
			_isMoving = true;
			break;

		case SDL_SCANCODE_RIGHT:
			_velX = _rightSpeed;
			_isMoving = true;
			break;

		case SDL_SCANCODE_SPACE:
			if (jumping == false && onGround == true) {
				_velY -= _jumpSpeed;
				jumping = true;
				onGround = false;
				_isMoving = true;
			}
			break;
		}

	else if (evnt.type == SDL_KEYUP) {
		switch (evnt.key.keysym.scancode) {

		case SDL_SCANCODE_LEFT:
			if (_velX < 0) {
				_velX = 0;
				_isMoving = false;
			}
			break;

		case SDL_SCANCODE_RIGHT:
			if (_velX > 0) {
				_velX = 0;
				_isMoving = false;
			}
			break;
		}
	}
}

void Player::move(float delta, std::vector<SDL_Rect> rects, int windowWidth, int windowHeight)
{
	//keeps track of the x and y coords before any movement. Used to know from which side the collision is from. 
	float xPos, yPos;
	xPos = posRect.x;
	yPos = posRect.y;

	//////////////////////////// X Movement ///////////////////////////////////////////

	//moves the player's x coord equal to the x velocity times delta
	posRect.x += _velX * delta; 
	
	//makes sure the player cant go outside the window on the left
	if (posRect.x < 0)
		posRect.x = 0;

	//majes sure the player cant go outside the window on the right
	if (posRect.x + posRect.w >= windowWidth)
		posRect.x = windowWidth - posRect.w;
	
	//////////////////////////// Y Movement //////////////////////////////////////////////

	//moves the player's y coord equal to the y velocity times delta
	posRect.y += _velY * delta;

	//applies gravity if the player is 
	if (posRect.y + posRect.h < windowHeight)
		posRect.y += gravity * delta;

	//the player cant fall through the bottom of the window
	if (posRect.y + posRect.h > windowHeight)
	{
		posRect.y = windowHeight - posRect.h;
		jumping = false;
		_velY += gravity * delta;
	}

	//the player cant move outside the top of the window
	if (posRect.y < 0)
		posRect.y = 0;

	//if the player is jumping (space is pressed) gravity is slowly applied to counter the jump speed
	if (jumping)
	{
			_velY += gravity * delta;
			onGround = false;
	}


	//collision checking for each object inside the vectors "rects"
	for (int i = 0; i < rects.size(); i++)
	{
		SDL_Rect &rect = rects[i];
		
		if (checkCollision(posRect, rect))
		{

			if (yPos + posRect.h <= rect.y)
			{
				jumping = false;
				_velY = 0;
				posRect.y = rect.y - posRect.h;
				onGround = true;
			}

			//colliding from left
			else if (xPos - rect.w >= rect.x)
			{
				if(rect.h == 32)
					posRect.x = rect.x + rect.w;
			}

			// colliding from right
			else if (xPos + posRect.w <= rect.x)
			{
				if(rect.h == 32)
					posRect.x = rect.x - posRect.w;
			}

			else if (yPos >= rect.y + rect.h)
			{
				if (rect.h == 32)
				{
					posRect.y = rect.y + rect.h;
					_velY += 700.0f;
				}

			}
	
		}
	}
}

//returns true if there is a collision, otherwise it returns false
bool Player::checkCollision(SDL_Rect posRect, SDL_Rect obj)
{
	//sets up variables which keeps track of the different parts of the rect
	//which makes it easier to understand the collision check 
	//posRect is the players coordinates, height and width, and obj for the object the player collides with
	int playerLeft, objLeft;
	int playerRight, objRight;
	int playerTop, objTop;
	int playerBottom, objBottom;

	playerLeft = posRect.x;
	playerRight = posRect.x + posRect.w;
	playerTop = posRect.y;
	playerBottom = posRect.y + posRect.h;

	objLeft = obj.x;
	objRight = obj.x + obj.w;
	objTop = obj.y;
	objBottom = obj.y + obj.h;


	//if none of the proceeding if-statements is true, there is a collision
	if (playerBottom <= objTop)
		return false;

	if (playerTop >= objBottom)
		return false;

	if (playerRight <= objLeft)
		return false;

	if (playerLeft >= objRight)
		return false;

	return true;
}