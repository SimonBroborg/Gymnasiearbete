#pragma once
#include <SDL\SDL.h>
#include <string>
#include <vector>
class Player
{
public:
	//creates the player sprite, x and y position and the number of frames for the player when the game starts
	Player(SDL_Renderer *renderer, std::string filePath, int x, int y, int framesX, int framesY);
	~Player();

	//Renders the player texture based on the position
	void render(SDL_Renderer *renderer);

	//takes the players inputs and calculates the movement of the player
	void processInput(SDL_Event &evnt, float delta);

	//moves the player based on the posRect's x and y coordinates. Also calls the checkCollision() function
	void move(float delta, std::vector<SDL_Rect> rects, int windowWidth, int windowHeight);

private:
	//checks the collision between the player and another rect. Returns true if there is a collision.
	bool checkCollision(SDL_Rect posRect, SDL_Rect obj);

	//The player sprite
	SDL_Texture *texture;

	//Booleans which checks movement, jumping and if the player is on the ground
	bool jumping, _isMoving, onGround;

	//the x and y velocity
	float _velX, _velY;

	//the speed which the player moves at to the left and right
	double _leftSpeed, _rightSpeed, _jumpSpeed;

	//the players gravity
	int gravity;

	//Keeps track of the players position
	SDL_Rect posRect;

	//Shows the current frame of the player on the sprite sheet
	SDL_Rect cropRect;

	//Checks which the active frame is
	float _frameCounter;

	//the dimensions of the player. Will help chosing the right part of the players sprite sheet
	int _frameWidth, _frameHeight;

	//width of the whole texture
	int _textureWidth;

	int acceleration;
};

