#include "Manager.h"

int main(int argc, char *argv[])
{
	Manager game;

	game.run();

	return 0;
}